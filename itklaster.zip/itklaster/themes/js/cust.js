$(function(){
	
	$('.phone_mask').mask('+7 (000) 000-00-00');

	//$.pixlayout({clip: true, src: "maket.png", show:true, center:true, top:0, left:0, pervious: false});

});

