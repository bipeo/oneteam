$(function(){
	var slick = $('.slick_slider').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		centerMode: true,
		variableWidth: true,
		dots:false,
                autoplay: true,
	});
});


