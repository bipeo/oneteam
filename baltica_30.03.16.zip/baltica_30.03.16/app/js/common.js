	$(function(){
           var boxs = $('.logform .form'),
           addmar = 150,
           minh = boxs.outerHeight();
          
           $('body').css('min-height',minh + addmar +'px'); 
        });
