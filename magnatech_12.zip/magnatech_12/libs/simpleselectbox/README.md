<p>This is a simple style select plugin, that allows custom option drop downs</p>  

<p>(Still in Progress)</p>
<p>Overall aims of this plugin are:</p>
<ul>
<li>
Select options via keyboard
</li>
<li>  
Add custom classes
</li>
<li>  
Set max height of option list 
</li>
<li>
Use of mobile default for user experience  
</li>
</ul>